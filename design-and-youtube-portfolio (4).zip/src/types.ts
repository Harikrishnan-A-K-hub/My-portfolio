export interface YouTubeChannel {
  id: string;
  name: string;
  handle: string;
  subscribers: string;
  videosCount: string;
  channelLink: string;
  imageUrl: string;
  description: string;
  accentColor: string; // hex or tailwind color class
  tags: string[];
}

export interface DesignWork {
  id: string;
  title: string;
  category: 'Web Design' | 'Graphic Design' | 'All';
  description: string;
  link: string;
  imageUrl: string;
  tags: string[];
  featured?: boolean;
}

export interface ContactInfo {
  discord: string;
  gmail: string;
  twitter?: string;
  github?: string;
}

export interface UserProfile {
  name: string;
  title: string;
  tagline: string;
  aboutMe: string;
  skills: string[];
  avatarUrl: string;
  heroBackgroundUrl?: string;
  backgroundVideoUrl?: string;
  backgroundVideoOpacity?: number;
}

export interface PortfolioData {
  profile: UserProfile;
  youtubeChannels: YouTubeChannel[];
  works: DesignWork[];
  contact: ContactInfo;
}
