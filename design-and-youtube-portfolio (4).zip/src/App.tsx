import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { getPortfolioData } from './data';
import { PortfolioData } from './types';
import Hero from './components/Hero';
import YouTubeHub from './components/YouTubeHub';
import WorksGrid from './components/WorksGrid';
import ContactSection from './components/ContactSection';
import FaqSection from './components/FaqSection';
import BackgroundLoop from './components/BackgroundLoop';
import AdminInbox from './components/AdminInbox';
import { 
  Youtube, Palette, Globe, Menu, X, ArrowUpRight, 
  Sparkles, ShieldCheck, Heart, Copyright 
} from 'lucide-react';

export default function App() {
  const [data, setData] = useState<PortfolioData>(getPortfolioData());
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [isAdminInboxOpen, setIsAdminInboxOpen] = useState(false);
  
  // State to toggle visibility of admin entry points
  const [isAdminMode, setIsAdminMode] = useState(() => {
    try {
      return localStorage.getItem('toeei_admin') === 'true';
    } catch {
      return false;
    }
  });

  const [logoClicks, setLogoClicks] = useState(0);

  // Monitor scrolling to style sticky navbar
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 30);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Check URL parameter on load
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('admin') === 'true') {
      try {
        localStorage.setItem('toeei_admin', 'true');
        setIsAdminMode(true);
        // Clean URL parameter so it's not visible in the browser address bar
        const url = new URL(window.location.href);
        url.searchParams.delete('admin');
        window.history.replaceState({}, '', url.pathname + url.search);
      } catch (err) {
        console.error(err);
      }
    }
  }, []);

  // Handle secret 5-clicks to toggle admin visibility
  const handleLogoClickSecret = () => {
    setLogoClicks(prev => {
      const next = prev + 1;
      if (next >= 5) {
        const nextMode = !isAdminMode;
        try {
          localStorage.setItem('toeei_admin', nextMode ? 'true' : 'false');
          setIsAdminMode(nextMode);
          alert(nextMode ? "🔑 Admin Control Panel Activated!" : "🔒 Admin Control Panel Deactivated!");
        } catch (err) {
          console.error(err);
        }
        return 0;
      }
      return next;
    });
  };

  // Scroll handlers
  const scrollToSection = (id: string) => {
    setIsMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-transparent text-neutral-100 flex flex-col font-sans selection:bg-red-600/30 selection:text-red-200">
      <BackgroundLoop 
        videoUrl={data.profile.backgroundVideoUrl} 
        opacity={data.profile.backgroundVideoOpacity} 
      />
      
      {/* Sticky Header */}
      <header 
        className={`fixed top-0 inset-x-0 z-40 transition-all duration-300 border-b ${
          scrolled 
            ? 'bg-black/80 backdrop-blur-md border-neutral-900/80 py-4 shadow-lg' 
            : 'bg-transparent border-transparent py-6'
        }`}
      >
        <div className="max-w-6xl mx-auto px-4 flex items-center justify-between">
          
          {/* Logo */}
          <button 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="flex items-center gap-2 group cursor-pointer"
          >
            <div 
              onClick={(e) => {
                e.stopPropagation();
                handleLogoClickSecret();
              }}
              className="w-9 h-9 rounded-xl bg-gradient-to-br from-red-750 to-red-600 flex items-center justify-center text-white font-extrabold text-sm shadow-md shadow-red-500/10 group-hover:scale-105 transition-transform"
            >
              T
            </div>
            <div className="text-left">
              <span className="block text-sm font-bold text-white tracking-tight leading-none group-hover:text-red-400 transition-colors">
                {data.profile.name}
              </span>
              <span className="block text-[9px] text-neutral-500 uppercase tracking-wider font-semibold font-mono mt-0.5">
                Creative Hub
              </span>
            </div>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-semibold text-neutral-400">
            <button 
              onClick={() => scrollToSection('youtube-section')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              YouTube Channels
            </button>
            <button 
              onClick={() => scrollToSection('works-section')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Design Works
            </button>
            <button 
              onClick={() => scrollToSection('about-section')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              About Me
            </button>
            <button 
              onClick={() => scrollToSection('contact-section')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Contact
            </button>
          </nav>

          {/* Action button */}
          <div className="hidden md:flex items-center gap-3">
            {isAdminMode && (
              <button
                onClick={() => setIsAdminInboxOpen(true)}
                className="bg-neutral-950 hover:bg-neutral-900 text-neutral-400 hover:text-red-500 border border-neutral-900 hover:border-neutral-800 p-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center"
                title="Admin Message Inbox"
              >
                <ShieldCheck className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={() => scrollToSection('contact-section')}
              className="bg-neutral-900 hover:bg-neutral-800 text-white border border-neutral-800 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer"
            >
              Get In Touch
            </button>
          </div>

          {/* Mobile menu trigger */}
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="p-1.5 hover:bg-neutral-900 rounded-lg text-neutral-400 hover:text-white transition-colors md:hidden cursor-pointer"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation Panel */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="absolute top-full left-0 right-0 bg-neutral-950 border-b border-neutral-900 shadow-2xl py-6 px-4 space-y-4 md:hidden overflow-hidden"
            >
              <div className="flex flex-col gap-4 text-sm font-bold text-neutral-400">
                <button 
                  onClick={() => scrollToSection('youtube-section')}
                  className="hover:text-white text-left cursor-pointer"
                >
                  YouTube Channels
                </button>
                <button 
                  onClick={() => scrollToSection('works-section')}
                  className="hover:text-white text-left cursor-pointer"
                >
                  Design Works
                </button>
                <button 
                  onClick={() => scrollToSection('about-section')}
                  className="hover:text-white text-left cursor-pointer"
                >
                  About Me
                </button>
                <button 
                  onClick={() => scrollToSection('contact-section')}
                  className="hover:text-white text-left cursor-pointer"
                >
                  Contact
                </button>
                
                {isAdminMode && (
                  <button
                    onClick={() => {
                      setIsMenuOpen(false);
                      setIsAdminInboxOpen(true);
                    }}
                    className="w-full text-center bg-neutral-900 hover:bg-neutral-800 text-red-500 hover:text-red-400 border border-neutral-850 py-2.5 rounded-xl text-xs font-bold cursor-pointer flex items-center justify-center gap-2 transition-all"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>Admin Inbox</span>
                  </button>
                )}
                
                <button
                  onClick={() => scrollToSection('contact-section')}
                  className="w-full text-center bg-white text-black py-2.5 rounded-xl text-xs font-extrabold cursor-pointer"
                >
                  Let's Collaborate
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Main Content Sections */}
      <main className="flex-1">
        
        {/* 1. Hero Presentation */}
        <Hero 
          profile={data.profile}
          channels={data.youtubeChannels}
          onScrollToWorks={() => scrollToSection('works-section')}
          onScrollToContact={() => scrollToSection('contact-section')}
        />

        {/* 2. YouTube Hub */}
        <YouTubeHub channels={data.youtubeChannels} />

        {/* 3. Design Works Grid */}
        <WorksGrid works={data.works} />

        {/* 4. Meet Creator Section (Replicating the screenshot's 'Meet Meily' aesthetic) */}
        <section id="about-section" className="py-24 px-4 bg-transparent relative overflow-hidden border-t border-neutral-900 font-sans">
          <div className="absolute top-1/4 left-1/4 w-80 h-80 bg-red-600/5 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-rose-600/5 rounded-full blur-3xl pointer-events-none" />
          
          <div className="max-w-5xl mx-auto relative z-10">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
              
              {/* Left text column */}
              <div className="lg:col-span-7 space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-red-500 font-semibold text-sm uppercase tracking-widest">
                    <Sparkles className="w-4 h-4" />
                    <span>Creative Designer & Host</span>
                  </div>
                  <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-display">
                    Meet {data.profile.name}
                  </h2>
                </div>

                <p className="text-neutral-400 text-sm sm:text-base leading-relaxed">
                  {data.profile.aboutMe}
                </p>

                {/* Styled Metrics Grid */}
                <div className="grid grid-cols-2 gap-4 pt-4">
                  <div className="p-4 bg-neutral-900/40 border border-neutral-800 rounded-xl space-y-1">
                    <span className="block text-2xl font-extrabold text-white font-display">1 Year</span>
                    <span className="block text-[10px] text-neutral-500 font-semibold uppercase tracking-wider">Design Experience</span>
                  </div>
                  <div className="p-4 bg-neutral-900/40 border border-neutral-800 rounded-xl space-y-1">
                    <span className="block text-lg sm:text-2xl font-extrabold text-white font-display">Looking for client</span>
                    <span className="block text-[10px] text-neutral-500 font-semibold uppercase tracking-wider">Availability</span>
                  </div>
                </div>

                {/* Skills Section */}
                <div className="space-y-3 pt-2">
                  <h4 className="text-xs font-extrabold uppercase tracking-widest text-neutral-400">Core Expertise & Tools</h4>
                  <div className="flex flex-wrap gap-2">
                    {data.profile.skills.map((skill, idx) => (
                      <span 
                        key={idx} 
                        className="px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 text-xs font-semibold text-neutral-300"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right image/visual column */}
              <div className="lg:col-span-5 relative flex flex-col items-center justify-center">
                
                {/* Visual Backdrop Frame */}
                <div className="absolute inset-0 bg-gradient-to-tr from-red-600/15 to-rose-600/5 rounded-3xl transform rotate-3 scale-102 blur-xl opacity-80" />
                
                 <div className="relative w-full max-w-[320px] aspect-[3/4] rounded-3xl overflow-hidden border border-neutral-800/80 bg-neutral-950 flex flex-col justify-between p-6 shadow-2xl group hover:border-red-500/20 transition-all duration-500">
                  
                  {/* Grid background decorative layout */}
                  <div className="absolute inset-0 bg-[linear-gradient(to_right,#141414_1px,transparent_1px),linear-gradient(to_bottom,#141414_1px,transparent_1px)] bg-[size:1.5rem_1.5rem] opacity-40" />

                  {/* Creator Photo Showcase */}
                  <div className="relative z-10 flex-1 w-full flex items-center justify-center py-4">
                    <img 
                      src={data.profile.avatarUrl} 
                      alt={data.profile.name}
                      referrerPolicy="no-referrer"
                      className="w-48 h-48 rounded-full border-4 border-neutral-800/85 object-cover shadow-2xl group-hover:scale-105 transition-transform duration-500 animate-fade-in"
                    />
                  </div>
                  
                  {/* Bottom title banner */}
                  <div className="relative z-10 bg-neutral-900/60 backdrop-blur-xs border border-neutral-800/80 p-4 rounded-2xl flex flex-col justify-end">
                    <span className="text-[10px] uppercase font-bold tracking-widest text-red-400 font-mono">Creative Director</span>
                    <h4 className="text-base font-bold text-white tracking-tight mt-0.5">{data.profile.name}</h4>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </section>

        {/* 5. Frequently Asked Questions */}
        <FaqSection />

        {/* 6. Contact Section */}
        <ContactSection contact={data.contact} />

      </main>

      {/* Footer */}
      <footer className="bg-transparent border-t border-neutral-900/60 py-12 px-4 text-center text-xs text-neutral-500 font-sans">
        <div className="max-w-4xl mx-auto space-y-6">
          
          {/* Top Logo */}
          <div className="flex justify-center items-center gap-2 text-white font-bold tracking-tight">
            <span 
              onClick={handleLogoClickSecret}
              className="w-6 h-6 rounded-lg bg-red-650 flex items-center justify-center text-xs cursor-pointer hover:scale-105 transition-transform"
            >
              T
            </span>
            <span>{data.profile.name}</span>
          </div>

          {/* Links */}
          <div className="flex flex-wrap justify-center gap-6 text-neutral-400 font-semibold text-xs">
            <button onClick={() => scrollToSection('youtube-section')} className="hover:text-white transition-colors cursor-pointer">YouTube Hub</button>
            <button onClick={() => scrollToSection('works-section')} className="hover:text-white transition-colors cursor-pointer">Design Works</button>
            <button onClick={() => scrollToSection('about-section')} className="hover:text-white transition-colors cursor-pointer">About Journey</button>
            <button onClick={() => scrollToSection('contact-section')} className="hover:text-white transition-colors cursor-pointer">Get in Touch</button>
          </div>

          <div className="border-t border-neutral-900/60 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-neutral-600">
            <div className="flex items-center gap-1.5">
              <Copyright className="w-3.5 h-3.5" />
              <span>{new Date().getFullYear()} {data.profile.name}. All Rights Reserved.</span>
            </div>
            <div className="flex items-center gap-1">
              <span>Made with</span>
              <Heart className="w-3 h-3 text-red-500 fill-red-500 animate-pulse" />
              <span>for YouTubers & Designers</span>
            </div>
          </div>
        </div>
      </footer>



      <AdminInbox 
        isOpen={isAdminInboxOpen}
        onClose={() => setIsAdminInboxOpen(false)}
      />

    </div>
  );
}
