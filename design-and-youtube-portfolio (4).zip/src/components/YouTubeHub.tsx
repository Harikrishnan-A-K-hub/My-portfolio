import React from 'react';
import { motion } from 'motion/react';
import { Youtube, Users, Video, ExternalLink, Sparkles } from 'lucide-react';
import { YouTubeChannel } from '../types';

interface YouTubeHubProps {
  channels: YouTubeChannel[];
}

export default function YouTubeHub({ channels }: YouTubeHubProps) {
  return (
    <section id="youtube-section" className="py-24 px-4 bg-transparent relative overflow-hidden border-t border-neutral-900">
      {/* Background radial highlight */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-red-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-6xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-4">
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-red-500 font-semibold text-sm uppercase tracking-widest">
              <Youtube className="w-5 h-5" />
              <span>01 / Content Creation</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-display">
              My YouTube Channels
            </h2>
            <p className="max-w-xl text-neutral-400 text-sm sm:text-base leading-relaxed">
              I run three distinct YouTube channels, each dedicated to a different side of my creative process. Front-end engineering, graphic design masterclasses, and creative lifestyle vlogs.
            </p>
          </div>
          
          <div className="flex items-center gap-2 bg-neutral-900/60 border border-neutral-800 px-4 py-2.5 rounded-xl text-xs text-neutral-400">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>Click cards to visit channel directly</span>
          </div>
        </div>

        {/* Channels Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {channels.map((channel, idx) => (
            <motion.a
              key={channel.id}
              href={channel.channelLink}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: idx * 0.15 }}
              whileHover={{ y: -8, transition: { duration: 0.2 } }}
              className="group relative flex flex-col bg-neutral-900/40 border border-neutral-800 hover:border-neutral-700/60 rounded-2xl p-6 overflow-hidden shadow-xl transition-all cursor-pointer backdrop-blur-xs"
            >
              {/* Colored top bar highlighting the accent color */}
              <div 
                className="absolute top-0 inset-x-0 h-1.5 transition-all duration-300 group-hover:h-2" 
                style={{ backgroundColor: channel.accentColor }}
              />

              {/* Glowing gradient backdrops on hover */}
              <div 
                className="absolute inset-0 opacity-0 group-hover:opacity-5 transition-opacity duration-300 pointer-events-none"
                style={{ 
                  background: `radial-gradient(circle at 50% 50%, ${channel.accentColor}, transparent 70%)` 
                }}
              />

              {/* Header inside Card */}
              <div className="flex items-center justify-between gap-4 mt-2">
                <div className="p-2.5 rounded-xl bg-red-600/10 border border-red-500/20 text-red-500 group-hover:bg-red-600 group-hover:text-white transition-all duration-300">
                  <Youtube className="w-5 h-5" />
                </div>

                <div className="flex flex-wrap gap-1.5 justify-end">
                  {channel.tags.slice(0, 2).map((tag, tIdx) => (
                    <span 
                      key={tIdx} 
                      className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-neutral-950 border border-neutral-800 text-neutral-400 group-hover:text-white transition-colors"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Titles */}
              <div className="mt-5 space-y-1">
                <h3 className="text-lg font-bold text-white group-hover:text-red-400 transition-colors tracking-tight flex items-center gap-1.5">
                  <span>{channel.name}</span>
                  <ExternalLink className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity text-neutral-500" />
                </h3>
                <p className="text-xs text-neutral-500 font-mono">{channel.handle}</p>
              </div>

              {/* Description */}
              <p className="mt-4 text-xs sm:text-sm text-neutral-400 line-clamp-3 leading-relaxed flex-1">
                {channel.description}
              </p>

              {/* Metrics row */}
              <div className="mt-6 pt-5 border-t border-neutral-800/80 grid grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-neutral-950 border border-neutral-800">
                    <Users className="w-3.5 h-3.5 text-neutral-500" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-white tracking-tight">{channel.subscribers}</p>
                    <p className="text-[9px] text-neutral-500 uppercase tracking-widest font-semibold">Subscribers</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-neutral-950 border border-neutral-800">
                    <Video className="w-3.5 h-3.5 text-neutral-500" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-white tracking-tight">{channel.videosCount}</p>
                    <p className="text-[9px] text-neutral-500 uppercase tracking-widest font-semibold">Videos</p>
                  </div>
                </div>
              </div>

              {/* Action Button inside Card */}
              <div className="mt-5 pt-3">
                <span className="w-full flex items-center justify-center gap-1.5 py-2 px-4 rounded-xl text-xs font-semibold bg-neutral-950 group-hover:bg-red-600/10 text-neutral-400 group-hover:text-red-400 border border-neutral-800 group-hover:border-red-600/30 transition-all duration-300">
                  <Youtube className="w-3.5 h-3.5 text-red-500" />
                  <span>Visit Channel</span>
                </span>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
