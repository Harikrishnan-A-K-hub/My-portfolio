import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';

interface BackgroundLoopProps {
  videoUrl?: string;
  opacity?: number;
}

export default function BackgroundLoop({ videoUrl = '/assets/background.mp4', opacity = 30 }: BackgroundLoopProps) {
  const [hasError, setHasError] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    // Reset error state if videoUrl changes
    setHasError(false);
  }, [videoUrl]);

  // Attempt to load and play the video when mounted or when URL changes
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.load();
      const playPromise = videoRef.current.play();
      if (playPromise !== undefined) {
        playPromise.catch((err) => {
          console.log("Autoplay paused or video file not found/provided yet. Falling back to topographic canvas.", err);
        });
      }
    }
  }, [videoUrl]);

  // High performance Canvas Topographic Loop Animation as a perfect fallback
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (canvas) {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
      }
    };
    window.addEventListener('resize', handleResize);

    // Create elevation contours
    const linesCount = 20;
    let offsetTime = 0;

    const render = () => {
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, width, height);

      offsetTime += 0.0022; // Smooth movement speed

      // Draw elegant topographic contour lines
      for (let i = 0; i < linesCount; i++) {
        const elevationFraction = i / linesCount;
        ctx.beginPath();
        
        // Thin glowing white-to-grey topographic lines
        const alpha = (0.04 + (1 - elevationFraction) * 0.15) * (opacity / 100 * 2.5);
        ctx.strokeStyle = `rgba(255, 255, 255, ${Math.min(alpha, 0.42)})`;
        ctx.lineWidth = 1.1;

        // Generate flow paths mimicking realistic topographic curves
        for (let x = 0; x <= width; x += 12) {
          const xFactor = x * 0.0022;
          const yOffset = (elevationFraction * height * 0.75) + (height * 0.12);
          
          // Superimposed trigonometric wave functions for natural terrain harmonics
          const wave1 = Math.sin(xFactor * 1.4 + offsetTime + elevationFraction * Math.PI) * 60;
          const wave2 = Math.cos(xFactor * 2.8 - offsetTime * 1.3 + elevationFraction * Math.PI * 0.4) * 28;
          const wave3 = Math.sin(xFactor * 0.65 + offsetTime * 0.6) * 40;
          
          const y = yOffset + wave1 + wave2 + wave3;

          if (x === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
      }

      // Draw tech-accented red glowing grid intersections
      ctx.fillStyle = 'rgba(239, 68, 68, 0.15)';
      for (let x = 64; x < width; x += 128) {
        for (let y = 64; y < height; y += 128) {
          ctx.beginPath();
          ctx.arc(x, y, 1.2, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [opacity]);

  return (
    <div className="fixed inset-0 w-full h-full -z-20 overflow-hidden bg-black select-none pointer-events-none">
      {/* Topographic Lines Canvas Flow */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full object-cover"
      />

      {/* Video Loop Element (takes overlay precedence if loaded successfully) */}
      {!hasError && videoUrl && (
        <video
          ref={videoRef}
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 z-10"
          style={{ opacity: opacity / 100 }}
          onError={() => setHasError(true)}
        >
          <source src={videoUrl} type="video/mp4" />
        </video>
      )}

      {/* Dark overlay guaranteeing superb readability of content */}
      <div 
        className="absolute inset-0 z-20 bg-black/60 transition-colors duration-500" 
        style={{ backgroundColor: `rgba(0, 0, 0, ${0.4 + (100 - opacity) * 0.0045})` }}
      />

      {/* Tech Red Accent Grid overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1a0505_1px,transparent_1px),linear-gradient(to_bottom,#1a0505_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_80%,transparent_100%)] opacity-35 z-30" />

      {/* Rich Glowing Crimson and Rose Nebulae */}
      <div className="absolute inset-0 z-0 overflow-hidden bg-transparent">
        <motion.div
          animate={{
            x: [0, 45, -25, 0],
            y: [0, -60, 35, 0],
            scale: [1, 1.12, 0.94, 1],
          }}
          transition={{
            duration: 24,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-1/4 left-1/4 w-[500px] h-[500px] rounded-full bg-red-600/10 blur-[120px]"
        />
        <motion.div
          animate={{
            x: [0, -55, 45, 0],
            y: [0, 35, -45, 0],
            scale: [1, 0.93, 1.07, 1],
          }}
          transition={{
            duration: 28,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute bottom-1/4 right-1/4 w-[600px] h-[600px] rounded-full bg-rose-800/8 blur-[130px]"
        />
      </div>
    </div>
  );
}
