import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { HelpCircle, ChevronDown, Plus, Minus } from 'lucide-react';

interface FaqItem {
  question: string;
  answer: string;
}

export default function FaqSection() {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const faqs: FaqItem[] = [
    {
      question: "What design services do you offer?",
      answer: "I specialize in complete branding identities, custom logo designs, packaging materials, typography poster designs, and modern full-stack web UI/UX development using tools like Figma, React, Tailwind CSS, and Webflow."
    },
    {
      question: "Can we hire you for sponsored content on your YouTube channels?",
      answer: "Absolutely! I love introducing my community of developers and designers to premium tools, hosting services, assets libraries, and developer gadgets. Feel free to contact me via Gmail with your sponsorship proposal."
    },
    {
      question: "What is your standard turnaround time for design projects?",
      answer: "Turnaround time depends entirely on project complexity. A custom brand identity with logo packages usually takes 1-2 weeks. A bespoke responsive landing page designed directly in Figma and coded in React takes around 2-3 weeks."
    },
    {
      question: "What technologies do you use for web development?",
      answer: "I build fast, type-safe, and highly interactive websites using React, Next.js, Vite, Tailwind CSS, TypeScript, and Framer Motion for premium fluid micro-interactions."
    },
    {
      question: "How can I join your Discord community?",
      answer: "Simply copy my Discord handle in the contact section below and add me! I can send you an invite link to our developer and designer circle where we share resource suggestions, reviews, and host weekly design sprints."
    }
  ];

  const toggleFaq = (idx: number) => {
    setOpenIdx(openIdx === idx ? null : idx);
  };

  return (
    <section className="py-24 px-4 bg-transparent relative overflow-hidden border-t border-neutral-900 font-sans">
      <div className="absolute top-1/2 right-1/4 w-80 h-80 bg-red-600/5 rounded-full blur-3xl pointer-events-none" />
      
      <div className="max-w-4xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-red-500 font-semibold text-sm uppercase tracking-widest">
              <HelpCircle className="w-4 h-4" />
              <span>03 / Frequently Asked Questions</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-display">
              Answers & Process
            </h2>
            <p className="max-w-lg text-neutral-400 text-sm sm:text-base leading-relaxed">
              Find answers to common questions about my design practices, video collaboration inquiries, and development procedures.
            </p>
          </div>
        </div>

        {/* Accordion list */}
        <div className="space-y-4">
          {faqs.map((faq, idx) => {
            const isOpen = openIdx === idx;
            return (
              <div 
                key={idx} 
                className={`border border-neutral-900 rounded-2xl overflow-hidden transition-all duration-300 ${
                  isOpen ? 'bg-neutral-900/30 border-neutral-800' : 'bg-neutral-900/10 hover:bg-neutral-900/20'
                }`}
              >
                <button
                  id={`faq-btn-${idx}`}
                  onClick={() => toggleFaq(idx)}
                  className="w-full flex items-center justify-between px-6 py-5 text-left text-white focus:outline-none cursor-pointer"
                >
                  <span className="text-sm sm:text-base font-bold tracking-tight">{faq.question}</span>
                  <div className={`p-1.5 rounded-lg border border-neutral-800 bg-neutral-950 text-neutral-400 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}>
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className="px-6 pb-6 pt-1 text-xs sm:text-sm text-neutral-400 leading-relaxed border-t border-neutral-900/40">
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
