import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mail, MessageSquare, Copy, Check, Send, 
  Sparkles, CheckCircle2, ChevronRight, MessageCircle 
} from 'lucide-react';
import { ContactInfo } from '../types';

interface ContactSectionProps {
  contact: ContactInfo;
}

export default function ContactSection({ contact }: ContactSectionProps) {
  const [copyDiscord, setCopyDiscord] = useState(false);
  const [copyGmail, setCopyGmail] = useState(false);
  
  // Local form state
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formSubject, setFormSubject] = useState('');
  const [formMessage, setFormMessage] = useState('');
  
  // Submission state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedMessage, setSubmittedMessage] = useState<any | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const handleCopyDiscord = () => {
    // Copy the discord handle dynamically from contact.discord
    navigator.clipboard.writeText(contact.discord);
    setCopyDiscord(true);
    setTimeout(() => setCopyDiscord(false), 2000);
  };

  const handleCopyGmail = () => {
    navigator.clipboard.writeText(contact.gmail);
    setCopyGmail(true);
    setTimeout(() => setCopyGmail(false), 2000);
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formEmail || !formMessage) return;

    setIsSubmitting(true);
    setSubmitError(null);
    
    const fallbackMessage = {
      id: String(Date.now() + Math.random().toString(36).substring(2, 6)),
      name: formName,
      email: formEmail,
      subject: formSubject || 'Design Inquiry',
      message: formMessage,
      timestamp: new Date().toISOString(),
      status: 'unread' as const
    };

    try {
      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: formName,
          email: formEmail,
          subject: formSubject || 'Design Inquiry',
          message: formMessage,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to submit message to the backend.');
      }

      const resData = await response.json();
      
      setIsSubmitting(false);
      setSubmittedMessage({
        id: resData.data.id,
        name: resData.data.name,
        email: resData.data.email,
        subject: resData.data.subject,
        message: resData.data.message,
        date: new Date(resData.data.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      });
    } catch (err) {
      console.warn("Backend unavailable, falling back to local storage:", err);
      
      try {
        const localMsgs = JSON.parse(localStorage.getItem('local_messages') || '[]');
        localMsgs.push(fallbackMessage);
        localStorage.setItem('local_messages', JSON.stringify(localMsgs));
      } catch (storageErr) {
        console.error("Failed to save to local storage:", storageErr);
      }

      setIsSubmitting(false);
      setSubmittedMessage({
        id: fallbackMessage.id,
        name: fallbackMessage.name,
        email: fallbackMessage.email,
        subject: fallbackMessage.subject,
        message: fallbackMessage.message,
        date: new Date(fallbackMessage.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      });
    }

    // Clear form
    setFormName('');
    setFormEmail('');
    setFormSubject('');
    setFormMessage('');
  };

  return (
    <section id="contact-section" className="py-24 px-4 bg-transparent relative overflow-hidden border-t border-neutral-900">
      {/* Background ambient elements - Red themed */}
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-[350px] h-[350px] bg-red-600/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 right-0 -translate-y-1/2 w-[350px] h-[350px] bg-rose-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-5xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-1.5 text-red-500 font-semibold text-sm uppercase tracking-widest justify-center">
            <MessageSquare className="w-5 h-5" />
            <span>03 / Connect Channels</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-display">
            Let's Collaborate
          </h2>
          <p className="text-neutral-400 text-sm sm:text-base leading-relaxed">
            Interested in hiring me for a design project, sponsoring a video, or just want to say hi? Reach out directly via Discord, Gmail, or submit a message below.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Direct Contact Cards (Discord + Gmail) */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* 1. Discord Card - Red & Black styling */}
            <div className="group relative bg-neutral-900/40 border border-neutral-800 hover:border-red-500/20 rounded-2xl p-6 transition-all duration-300">
              {/* Subtle top indicator */}
              <div className="absolute top-0 left-6 right-6 h-0.5 bg-red-500/0 group-hover:bg-red-500/40 transition-colors duration-300" />
              
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-red-600/10 rounded-xl border border-red-500/20 text-red-400 group-hover:bg-red-600 group-hover:text-white transition-all duration-300">
                    <MessageCircle className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-neutral-500">Contact via Discord</span>
                    <h3 className="text-lg font-bold text-white mt-0.5">Discord Community</h3>
                  </div>
                </div>
                
                <span className="text-[10px] text-red-400 bg-red-500/10 px-2.5 py-0.5 rounded-full border border-red-500/20 font-semibold uppercase tracking-wider animate-pulse">
                  Online
                </span>
              </div>

              <p className="text-xs text-neutral-400 mt-4 leading-relaxed">
                Add me on Discord to start a direct conversation, request custom quotes, discuss sponsorships, or collaborate on your next project. I'm usually active throughout the day!
              </p>

              {/* Box displaying handle for easy copy */}
              <div className="mt-6 flex items-center justify-between bg-neutral-950 border border-neutral-800/80 rounded-xl px-4 py-3">
                <div className="flex flex-col">
                  <span className="text-[9px] uppercase tracking-wider text-neutral-500 font-bold">Discord Username</span>
                  <span className="text-sm font-semibold font-mono text-white tracking-wide">{contact.discord}</span>
                </div>
                <button
                  id="copy-discord-btn"
                  onClick={handleCopyDiscord}
                  className={`flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                    copyDiscord 
                      ? 'bg-red-600 text-white shadow-md shadow-red-600/20' 
                      : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white'
                  }`}
                >
                  {copyDiscord ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Tag</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* 2. Gmail Card - Red & Black styling */}
            <div className="group relative bg-neutral-900/40 border border-neutral-800 hover:border-red-500/20 rounded-2xl p-6 transition-all duration-300">
              <div className="absolute top-0 left-6 right-6 h-0.5 bg-red-500/0 group-hover:bg-red-500/40 transition-colors duration-300" />
              
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-red-600/10 rounded-xl border border-red-500/20 text-red-400 group-hover:bg-red-600 group-hover:text-white transition-all duration-300">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-neutral-500">Contact via Email</span>
                    <h3 className="text-lg font-bold text-white mt-0.5">Direct Gmail</h3>
                  </div>
                </div>
                
                <span className="text-[10px] text-red-400 bg-red-500/10 px-2.5 py-0.5 rounded-full border border-red-500/20 font-semibold uppercase tracking-wider">
                  Inquiries
                </span>
              </div>

              <p className="text-xs text-neutral-400 mt-4 leading-relaxed">
                Send a formal message for design orders, media/vlog collaborations, speaking engagements, or professional inquiries.
              </p>

              {/* Box displaying email */}
              <div className="mt-6 flex flex-col gap-2">
                <div className="flex items-center justify-between bg-neutral-950 border border-neutral-800/80 rounded-xl px-4 py-3">
                  <span className="text-xs sm:text-sm font-semibold font-mono text-white tracking-tight truncate max-w-[150px] sm:max-w-[200px]">{contact.gmail}</span>
                  <button
                    id="copy-gmail-btn"
                    onClick={handleCopyGmail}
                    className={`flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                      copyGmail 
                        ? 'bg-red-600 text-white shadow-md shadow-red-600/20' 
                        : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white'
                    }`}
                  >
                    {copyGmail ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Email</span>
                      </>
                    )}
                  </button>
                </div>
                
                <a
                  href={`mailto:${contact.gmail}?subject=Creative%20Design%20Collaboration`}
                  className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs font-semibold bg-neutral-900/60 hover:bg-red-600/10 hover:text-red-400 text-neutral-400 border border-neutral-800 hover:border-red-500/30 transition-all duration-300"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Open Email App</span>
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Custom Message Form */}
          <div className="lg:col-span-7 bg-neutral-900/20 border border-neutral-900 rounded-2xl p-6 sm:p-8 relative">
            <h3 className="text-xl font-bold text-white tracking-tight mb-1">Send a Message</h3>
            <p className="text-xs text-neutral-400 mb-6">Fill in the fields below. We will simulate sending and display your message payload.</p>

            <form onSubmit={handleFormSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">Your Name *</label>
                  <input
                    id="contact-form-name"
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-red-500 transition-colors"
                    placeholder="John Doe"
                  />
                </div>
                
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">Your Email *</label>
                  <input
                    id="contact-form-email"
                    type="email"
                    required
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-red-500 transition-colors"
                    placeholder="john@example.com"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">Subject / Inquiry Type</label>
                <input
                  id="contact-form-subject"
                  type="text"
                  value={formSubject}
                  onChange={(e) => setFormSubject(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-red-500 transition-colors"
                  placeholder="e.g. YouTube Sponsorship, Web Design Project..."
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">Your Message *</label>
                <textarea
                  id="contact-form-message"
                  required
                  rows={4}
                  value={formMessage}
                  onChange={(e) => setFormMessage(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-red-500 transition-colors resize-none"
                  placeholder="Hey! Love your work. Let's collaborate on a creative graphic design design..."
                />
              </div>

              {submitError && (
                <div className="p-3 bg-red-950/20 border border-red-500/20 rounded-xl text-xs text-red-400 font-semibold text-center">
                  {submitError}
                </div>
              )}

              <button
                id="contact-form-submit"
                type="submit"
                disabled={isSubmitting}
                className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-red-700 to-red-600 hover:from-red-600 hover:to-red-500 text-white font-semibold py-3 rounded-xl transition-all shadow-lg hover:shadow-red-500/25 active:scale-98 disabled:opacity-50 cursor-pointer"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Processing Message...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Submit Message</span>
                  </>
                )}
              </button>
            </form>
          </div>
        </div>

        {/* Modal display of submitted message */}
        <AnimatePresence>
          {submittedMessage && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/70 backdrop-blur-md z-50 flex items-center justify-center p-4 font-sans"
            >
              <motion.div
                initial={{ scale: 0.95, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.95, y: 20 }}
                className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-lg w-full p-6 text-neutral-100 shadow-2xl space-y-4"
              >
                <div className="flex items-center gap-3 border-b border-neutral-800 pb-3">
                  <div className="p-2 bg-red-500/10 text-red-400 rounded-full">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">Message Logged Locally!</h3>
                    <p className="text-xs text-neutral-400">Your message was captured successfully</p>
                  </div>
                </div>

                <div className="space-y-3 bg-neutral-950 border border-neutral-800 rounded-xl p-4 text-xs font-mono">
                  <div className="flex justify-between">
                    <span className="text-neutral-500">FROM:</span>
                    <span className="text-white font-semibold">{submittedMessage.name} ({submittedMessage.email})</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-500">SUBJECT:</span>
                    <span className="text-red-400 font-semibold">{submittedMessage.subject}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-500">TIMESTAMP:</span>
                    <span className="text-neutral-400">{submittedMessage.date}</span>
                  </div>
                  <div className="border-t border-neutral-800 pt-3 mt-1 text-neutral-300 leading-relaxed max-h-32 overflow-y-auto whitespace-pre-wrap font-sans">
                    "{submittedMessage.message}"
                  </div>
                </div>

                <div className="text-xs text-neutral-400 bg-neutral-950/40 p-3 rounded-lg leading-relaxed flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-red-500 flex-shrink-0" />
                  <span>This message simulation displays how submission logs will look on your dashboard. Perfect for live testing!</span>
                </div>

                <button
                  id="close-success-modal"
                  onClick={() => setSubmittedMessage(null)}
                  className="w-full py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white font-semibold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  Close Confirmation
                </button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
