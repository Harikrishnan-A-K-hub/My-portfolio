import React from 'react';
import { motion } from 'motion/react';
import { Youtube, Palette, Globe, ChevronDown, ArrowUpRight } from 'lucide-react';
import { UserProfile, YouTubeChannel } from '../types';

interface HeroProps {
  profile: UserProfile;
  channels: YouTubeChannel[];
  onScrollToWorks: () => void;
  onScrollToContact: () => void;
}

export default function Hero({ profile, channels, onScrollToWorks, onScrollToContact }: HeroProps) {
  // Aggregate stats
  const totalSubscribers = channels.reduce((acc, ch) => {
    // Parse K format to absolute value or just join them
    return acc + parseFloat(ch.subscribers.replace('K', ''));
  }, 0);

  return (
    <section className="relative min-h-[90vh] flex flex-col justify-center items-center px-4 overflow-hidden py-20 bg-transparent">
      {/* Background ambient glows */}
      <div className="absolute top-1/4 left-1/4 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 translate-x-1/2 translate-y-1/2 w-[400px] h-[400px] bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />
      
      {/* Subtle grid background overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1f1f1f_1px,transparent_1px),linear-gradient(to_bottom,#1f1f1f_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-30 pointer-events-none" />

      <div className="max-w-4xl mx-auto text-center relative z-10 space-y-8">
        {/* Available for work badge */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-neutral-900 border border-neutral-800 text-xs font-semibold text-neutral-300 shadow-xl"
        >
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>Available for Design & YouTube collaborations</span>
        </motion.div>

        {/* Main Headings */}
        <div className="space-y-4">
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="text-4xl sm:text-6xl md:text-7.5xl font-extrabold tracking-tight font-display text-white leading-none"
          >
            Branding & Web Design <br />
            <span className="bg-gradient-to-r from-red-500 via-rose-500 to-amber-500 bg-clip-text text-transparent">
              That Commands Attention
            </span>
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="max-w-2xl mx-auto text-neutral-400 text-base sm:text-lg md:text-xl font-normal leading-relaxed font-sans"
          >
            {profile.tagline}
          </motion.p>
        </div>

        {/* Dynamic Badges */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="flex flex-wrap justify-center gap-2.5 max-w-lg mx-auto"
        >
          <div className="flex items-center gap-1.5 bg-neutral-900/80 hover:bg-neutral-900 px-4 py-2 rounded-xl border border-neutral-800 text-xs font-bold text-white transition-all shadow-md">
            <Globe className="w-4 h-4 text-red-500" />
            <span>Web Designer</span>
          </div>
          <div className="flex items-center gap-1.5 bg-neutral-900/80 hover:bg-neutral-900 px-4 py-2 rounded-xl border border-neutral-800 text-xs font-bold text-white transition-all shadow-md">
            <Palette className="w-4 h-4 text-rose-500" />
            <span>Graphic Designer</span>
          </div>
          <div className="flex items-center gap-1.5 bg-neutral-900/80 hover:bg-neutral-900 px-4 py-2 rounded-xl border border-neutral-800 text-xs font-bold text-white transition-all shadow-md">
            <Youtube className="w-4 h-4 text-red-500" />
            <span>Content Creator</span>
          </div>
        </motion.div>

        {/* Call to Actions */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="flex flex-col sm:flex-row justify-center items-center gap-4 pt-4"
        >
          <button
            onClick={onScrollToWorks}
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-white text-black font-semibold hover:bg-neutral-200 active:scale-95 transition-all flex items-center justify-center gap-2 shadow-xl hover:shadow-white/5 cursor-pointer"
          >
            <span>View Design Works</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
          <button
            onClick={onScrollToContact}
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white font-semibold border border-neutral-800 transition-all flex items-center justify-center gap-2 active:scale-95 cursor-pointer"
          >
            <span>Let's Collaborated</span>
          </button>
        </motion.div>

        {/* Statistics Banner */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="grid grid-cols-3 gap-4 max-w-xl mx-auto pt-12 border-t border-neutral-900/60"
        >
          <div className="text-center">
            <p className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-display">1.48k</p>
            <p className="text-[10px] sm:text-xs text-neutral-500 font-semibold uppercase tracking-wider mt-1">YouTube Subscribers</p>
          </div>
          <div className="text-center border-x border-neutral-900">
            <p className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-display">3</p>
            <p className="text-[10px] sm:text-xs text-neutral-500 font-semibold uppercase tracking-wider mt-1">YouTube Channels</p>
          </div>
          <div className="text-center">
            <p className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-display">100%</p>
            <p className="text-[10px] sm:text-xs text-neutral-500 font-semibold uppercase tracking-wider mt-1">Creative Dedication</p>
          </div>
        </motion.div>
      </div>

      {/* Down arrow indicator */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5 text-neutral-500 hover:text-white transition-colors cursor-pointer pointer-events-auto" onClick={onScrollToWorks}>
        <span className="text-[10px] uppercase tracking-widest font-semibold">Explore Portfolio</span>
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
        >
          <ChevronDown className="w-4 h-4" />
        </motion.div>
      </div>
    </section>
  );
}
