import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Lock, Unlock, Inbox, Mail, Trash2, CheckCircle, 
  X, Search, Calendar, User, Eye, RefreshCw, 
  AlertCircle, Filter, ChevronRight, CheckSquare, ShieldAlert
} from 'lucide-react';

interface Message {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  timestamp: string;
  status: 'read' | 'unread';
}

interface AdminInboxProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AdminInbox({ isOpen, onClose }: AdminInboxProps) {
  const [passcode, setPasscode] = useState('');
  const [unlockedPasscode, setUnlockedPasscode] = useState('');
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [passcodeError, setPasscodeError] = useState(false);
  
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'unread' | 'read'>('all');
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null);
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);

  // Hardcoded simple admin passcode
  const CORRECT_PASSCODE = 'admin123';

  useEffect(() => {
    // If already unlocked and inbox is open, fetch messages
    if (isUnlocked && isOpen) {
      fetchMessages();
    }
  }, [isUnlocked, isOpen]);

  const fetchMessages = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/messages', {
        headers: {
          'x-admin-passcode': unlockedPasscode || CORRECT_PASSCODE
        }
      });
      
      const localMsgs = JSON.parse(localStorage.getItem('local_messages') || '[]');
      
      if (res.ok) {
        const data = await res.json();
        const apiMsgs = data.data || [];
        const combined = [...localMsgs, ...apiMsgs];
        const seen = new Set();
        const deduped = combined.filter((m: any) => {
          if (seen.has(m.id)) return false;
          seen.add(m.id);
          return true;
        });
        setMessages(deduped);
      } else {
        throw new Error("Failed to fetch messages");
      }
    } catch (err) {
      console.warn("Error fetching messages, falling back to localStorage:", err);
      const localMsgs = JSON.parse(localStorage.getItem('local_messages') || '[]');
      setMessages(localMsgs);
    } finally {
      setIsLoading(false);
    }
  };

  const handleUnlockSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (passcode === CORRECT_PASSCODE) {
      setUnlockedPasscode(passcode);
      setIsUnlocked(true);
      setPasscodeError(false);
    } else {
      setPasscodeError(true);
      setPasscode('');
      setTimeout(() => setPasscodeError(false), 2000);
    }
  };

  const handleToggleReadStatus = async (id: string, currentStatus: 'read' | 'unread') => {
    setActionLoadingId(id);
    const newStatus = currentStatus === 'read' ? 'unread' : 'read';
    try {
      const res = await fetch(`/api/messages/${id}`, {
        method: 'PATCH',
        headers: { 
          'Content-Type': 'application/json',
          'x-admin-passcode': unlockedPasscode || CORRECT_PASSCODE
        },
        body: JSON.stringify({ status: newStatus })
      });
      if (res.ok) {
        setMessages(prev => prev.map(m => m.id === id ? { ...m, status: newStatus } : m));
        if (selectedMessage?.id === id) {
          setSelectedMessage(prev => prev ? { ...prev, status: newStatus } : null);
        }
      } else {
        throw new Error("Failed to update status on server");
      }
    } catch (err) {
      console.warn("Error updating status on server, updating locally only:", err);
      setMessages(prev => prev.map(m => m.id === id ? { ...m, status: newStatus } : m));
      if (selectedMessage?.id === id) {
        setSelectedMessage(prev => prev ? { ...prev, status: newStatus } : null);
      }
      try {
        const localMsgs = JSON.parse(localStorage.getItem('local_messages') || '[]');
        const updatedLocal = localMsgs.map((m: any) => m.id === id ? { ...m, status: newStatus } : m);
        localStorage.setItem('local_messages', JSON.stringify(updatedLocal));
      } catch (storageErr) {
        console.error("Failed to update local storage:", storageErr);
      }
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleDeleteMessage = async (id: string) => {
    if (!confirm("Are you sure you want to permanently delete this message?")) return;
    setActionLoadingId(id);
    try {
      const res = await fetch(`/api/messages/${id}`, {
        method: 'DELETE',
        headers: {
          'x-admin-passcode': unlockedPasscode || CORRECT_PASSCODE
        }
      });
      if (res.ok) {
        setMessages(prev => prev.filter(m => m.id !== id));
        if (selectedMessage?.id === id) {
          setSelectedMessage(null);
        }
      } else {
        throw new Error("Failed to delete message on server");
      }
    } catch (err) {
      console.warn("Error deleting message from server, deleting locally only:", err);
      setMessages(prev => prev.filter(m => m.id !== id));
      if (selectedMessage?.id === id) {
        setSelectedMessage(null);
      }
      try {
        const localMsgs = JSON.parse(localStorage.getItem('local_messages') || '[]');
        const updatedLocal = localMsgs.filter((m: any) => m.id !== id);
        localStorage.setItem('local_messages', JSON.stringify(updatedLocal));
      } catch (storageErr) {
        console.error("Failed to delete from local storage:", storageErr);
      }
    } finally {
      setActionLoadingId(null);
    }
  };

  // Filter and search logic
  const filteredMessages = messages.filter(msg => {
    const matchesSearch = 
      msg.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      msg.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      msg.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      msg.message.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (activeTab === 'unread') return matchesSearch && msg.status === 'unread';
    if (activeTab === 'read') return matchesSearch && msg.status === 'read';
    return matchesSearch;
  });

  // Stats calculation
  const totalCount = messages.length;
  const unreadCount = messages.filter(m => m.status === 'unread').length;
  const readCount = messages.filter(m => m.status === 'read').length;

  const formatDate = (isoStr: string) => {
    try {
      const d = new Date(isoStr);
      return d.toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    } catch {
      return isoStr;
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/90 backdrop-blur-xl flex items-center justify-center p-4 font-sans text-neutral-100">
      
      {/* Outer wrapper card */}
      <div className="relative w-full max-w-4xl bg-neutral-950 border border-neutral-900 rounded-3xl overflow-hidden shadow-2xl h-[85vh] flex flex-col">
        
        {/* Header decoration */}
        <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-red-500 to-transparent" />

        {/* Top Header - Always visible */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-900 bg-neutral-950/50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-red-600/10 text-red-500 rounded-xl border border-red-500/20">
              <Inbox className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-white tracking-tight">Admin Inquiry Hub</h2>
              <p className="text-[10px] text-neutral-500 font-mono tracking-wider uppercase">Portfolio Back-end Engine</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 hover:bg-neutral-900 rounded-lg text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Lock Screen / Passcode Gate */}
        {!isUnlocked ? (
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center max-w-sm mx-auto space-y-6">
            <motion.div 
              animate={passcodeError ? { x: [-10, 10, -10, 10, 0] } : {}}
              transition={{ duration: 0.4 }}
              className={`p-5 rounded-full border ${
                passcodeError 
                  ? 'bg-red-500/10 border-red-500/30 text-red-500' 
                  : 'bg-neutral-900/60 border-neutral-800 text-neutral-400'
              }`}
            >
              <Lock className="w-10 h-10" />
            </motion.div>
            
            <div className="space-y-2">
              <h3 className="text-xl font-bold text-white tracking-tight">Enter Passcode</h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                This area is password protected. Please enter the Toeei portfolio passcode.
              </p>
            </div>

            <form onSubmit={handleUnlockSubmit} className="w-full space-y-3">
              <div className="relative">
                <input
                  type="password"
                  required
                  placeholder="Enter passcode"
                  value={passcode}
                  onChange={(e) => setPasscode(e.target.value)}
                  className={`w-full bg-neutral-900/40 border rounded-xl px-4 py-3 text-sm text-center text-white placeholder-neutral-600 focus:outline-none transition-colors ${
                    passcodeError ? 'border-red-500/60' : 'border-neutral-800 focus:border-red-500/50'
                  }`}
                />
              </div>

              <button
                type="submit"
                className="w-full bg-red-600 hover:bg-red-500 text-white font-semibold py-2.5 rounded-xl text-xs tracking-wide transition-colors shadow-lg shadow-red-600/10 cursor-pointer"
              >
                Access Dashboard
              </button>
            </form>
          </div>
        ) : (
          /* Main Inbox Dashboard View */
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            
            {/* Left sidebar: Message List & Filtering */}
            <div className="w-full md:w-5/12 border-r border-neutral-900 flex flex-col h-full bg-neutral-950/20">
              
              {/* Stats Panel */}
              <div className="grid grid-cols-3 gap-2 p-4 border-b border-neutral-900 bg-neutral-950/40">
                <div className="bg-neutral-900/30 border border-neutral-900 rounded-xl p-2.5 text-center">
                  <span className="block text-neutral-500 text-[10px] font-bold uppercase font-mono">All</span>
                  <span className="text-base font-bold text-white mt-1 block">{totalCount}</span>
                </div>
                <div className="bg-red-500/5 border border-red-950/40 rounded-xl p-2.5 text-center">
                  <span className="block text-red-400 text-[10px] font-bold uppercase font-mono">Unread</span>
                  <span className="text-base font-bold text-red-500 mt-1 block">{unreadCount}</span>
                </div>
                <div className="bg-neutral-900/30 border border-neutral-900 rounded-xl p-2.5 text-center">
                  <span className="block text-neutral-500 text-[10px] font-bold uppercase font-mono">Read</span>
                  <span className="text-base font-bold text-neutral-300 mt-1 block">{readCount}</span>
                </div>
              </div>

              {/* Filters & Search & Refresh */}
              <div className="p-3 space-y-3 border-b border-neutral-900">
                
                {/* Tabs */}
                <div className="flex bg-neutral-950/60 p-1 border border-neutral-900 rounded-xl text-xs">
                  <button 
                    onClick={() => setActiveTab('all')}
                    className={`flex-1 py-1.5 rounded-lg text-center font-semibold transition-colors ${
                      activeTab === 'all' 
                        ? 'bg-neutral-900 text-white shadow-sm' 
                        : 'text-neutral-500 hover:text-neutral-300'
                    }`}
                  >
                    All
                  </button>
                  <button 
                    onClick={() => setActiveTab('unread')}
                    className={`flex-1 py-1.5 rounded-lg text-center font-semibold transition-colors flex justify-center items-center gap-1.5 ${
                      activeTab === 'unread' 
                        ? 'bg-red-950/30 text-red-400 border border-red-500/10 shadow-sm' 
                        : 'text-neutral-500 hover:text-neutral-300'
                    }`}
                  >
                    Unread
                    {unreadCount > 0 && (
                      <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
                    )}
                  </button>
                  <button 
                    onClick={() => setActiveTab('read')}
                    className={`flex-1 py-1.5 rounded-lg text-center font-semibold transition-colors ${
                      activeTab === 'read' 
                        ? 'bg-neutral-900 text-white shadow-sm' 
                        : 'text-neutral-500 hover:text-neutral-300'
                    }`}
                  >
                    Read
                  </button>
                </div>

                {/* Search Bar & Refresh */}
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" />
                    <input
                      type="text"
                      placeholder="Search messages..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full bg-neutral-900/50 border border-neutral-900 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500/50"
                    />
                  </div>
                  <button
                    onClick={fetchMessages}
                    disabled={isLoading}
                    title="Refresh Feed"
                    className="p-2 bg-neutral-900 border border-neutral-800 hover:border-neutral-700 hover:text-white rounded-xl text-neutral-400 transition-colors cursor-pointer flex-shrink-0 disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                  </button>
                </div>
              </div>

              {/* Messages list */}
              <div className="flex-1 overflow-y-auto division-y divide-neutral-900">
                {isLoading ? (
                  <div className="py-12 flex flex-col items-center justify-center gap-2 text-xs text-neutral-500 font-mono">
                    <RefreshCw className="w-5 h-5 animate-spin text-red-500" />
                    <span>FETCHING REAL-TIME LOGS...</span>
                  </div>
                ) : filteredMessages.length === 0 ? (
                  <div className="py-16 text-center text-xs text-neutral-500 font-mono space-y-2">
                    <AlertCircle className="w-5 h-5 mx-auto text-neutral-600" />
                    <p>NO INQUIRIES FOUND</p>
                  </div>
                ) : (
                  filteredMessages.map((msg) => (
                    <button
                      key={msg.id}
                      onClick={() => setSelectedMessage(msg)}
                      className={`w-full text-left p-4 flex flex-col gap-1.5 hover:bg-neutral-900/30 border-b border-neutral-900 transition-colors relative cursor-pointer ${
                        selectedMessage?.id === msg.id ? 'bg-neutral-900/40 border-l-2 border-l-red-500 pl-3.5' : ''
                      }`}
                    >
                      {msg.status === 'unread' && (
                        <span className="absolute top-4 right-4 w-2 h-2 rounded-full bg-red-500 shadow-lg shadow-red-500/50" />
                      )}

                      <div className="flex items-center justify-between pr-4">
                        <span className="font-bold text-xs text-white leading-none truncate max-w-[120px]">{msg.name}</span>
                        <span className="text-[9px] text-neutral-500 font-mono">{formatDate(msg.timestamp)}</span>
                      </div>
                      
                      <span className="text-xs font-semibold text-neutral-300 truncate">{msg.subject}</span>
                      <span className="text-[11px] text-neutral-500 truncate leading-tight">{msg.message}</span>
                    </button>
                  ))
                )}
              </div>
            </div>

            {/* Right sidebar: Message detail reader */}
            <div className="flex-1 flex flex-col h-full bg-neutral-950/40">
              {selectedMessage ? (
                <div className="flex-1 flex flex-col h-full">
                  
                  {/* Subject and Action buttons */}
                  <div className="p-6 border-b border-neutral-900 bg-neutral-950/60 flex items-start justify-between gap-4">
                    <div className="space-y-1.5 flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className={`text-[9px] font-extrabold uppercase font-mono px-2 py-0.5 rounded-md border ${
                          selectedMessage.status === 'unread'
                            ? 'bg-red-500/10 border-red-500/20 text-red-400'
                            : 'bg-neutral-800/50 border-neutral-700/50 text-neutral-400'
                        }`}>
                          {selectedMessage.status}
                        </span>
                        <span className="text-[9px] text-neutral-500 font-mono truncate">ID: {selectedMessage.id}</span>
                      </div>
                      <h3 className="text-lg font-bold text-white tracking-tight leading-tight">{selectedMessage.subject}</h3>
                    </div>

                    {/* Quick action buttons */}
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleToggleReadStatus(selectedMessage.id, selectedMessage.status)}
                        disabled={actionLoadingId === selectedMessage.id}
                        title={selectedMessage.status === 'read' ? "Mark as Unread" : "Mark as Read"}
                        className="p-2 bg-neutral-900 border border-neutral-800 hover:border-neutral-700 hover:text-white rounded-xl text-neutral-400 transition-colors cursor-pointer flex-shrink-0 disabled:opacity-50"
                      >
                        <CheckSquare className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteMessage(selectedMessage.id)}
                        disabled={actionLoadingId === selectedMessage.id}
                        title="Delete Message"
                        className="p-2 bg-neutral-900 border border-neutral-800 hover:border-red-500/30 hover:text-red-400 rounded-xl text-neutral-400 transition-colors cursor-pointer flex-shrink-0 disabled:opacity-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Metadata cards */}
                  <div className="px-6 py-4 border-b border-neutral-900 bg-neutral-950/20 grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 bg-neutral-900 border border-neutral-800 rounded-xl text-neutral-400">
                        <User className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <span className="block text-[8px] font-bold text-neutral-500 uppercase font-mono tracking-wider">Sender Name</span>
                        <span className="block text-xs font-semibold text-white truncate">{selectedMessage.name}</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 bg-neutral-900 border border-neutral-800 rounded-xl text-neutral-400">
                        <Mail className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <span className="block text-[8px] font-bold text-neutral-500 uppercase font-mono tracking-wider">Email Address</span>
                        <a href={`mailto:${selectedMessage.email}`} className="block text-xs font-semibold text-red-400 hover:underline truncate">{selectedMessage.email}</a>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5 sm:col-span-2">
                      <div className="p-2 bg-neutral-900 border border-neutral-800 rounded-xl text-neutral-400">
                        <Calendar className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <span className="block text-[8px] font-bold text-neutral-500 uppercase font-mono tracking-wider">Date Sent (ISO Timestamp)</span>
                        <span className="block text-xs font-semibold text-neutral-300 truncate">{new Date(selectedMessage.timestamp).toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  {/* Message body reader */}
                  <div className="flex-1 p-6 overflow-y-auto">
                    <span className="block text-[8px] font-bold text-neutral-500 uppercase font-mono tracking-wider mb-2.5">Message Content</span>
                    <div className="bg-neutral-900/40 border border-neutral-900 rounded-2xl p-4 sm:p-5 text-sm leading-relaxed text-neutral-200 whitespace-pre-wrap font-sans">
                      "{selectedMessage.message}"
                    </div>
                  </div>

                  {/* Bottom indicator action */}
                  <div className="p-4 bg-neutral-950/40 border-t border-neutral-900 flex justify-end gap-2 text-xs">
                    <a 
                      href={`mailto:${selectedMessage.email}?subject=RE: ${encodeURIComponent(selectedMessage.subject)}`}
                      className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-semibold rounded-xl transition-colors cursor-pointer"
                    >
                      Reply via Email
                    </a>
                  </div>

                </div>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center p-6 text-center text-neutral-500 font-mono space-y-3">
                  <Eye className="w-10 h-10 text-neutral-700" />
                  <div>
                    <h4 className="text-xs uppercase font-extrabold tracking-widest text-neutral-400">No Message Selected</h4>
                    <p className="text-[10px] text-neutral-500 mt-1 max-w-[200px] leading-relaxed mx-auto">Click on any message card in the feed sidebar to read its details</p>
                  </div>
                </div>
              )}
            </div>

          </div>
        )}

      </div>
    </div>
  );
}
