import { PortfolioData } from './types';
import toyForImg from './assets/images/toy_for_1782912245332.jpg';
import toyYtImg from './assets/images/toy_yt_1782912261816.jpg';
import lelarImg from './assets/images/lelar_1782912278598.jpg';

export const INITIAL_PORTFOLIO_DATA: PortfolioData = {
  profile: {
    name: "Toeei",
    title: "Web Designer & Graphic Designer & YouTuber",
    tagline: "Designing digital products, crafting visual identities, and sharing the creative journey.",
    aboutMe: "I am a multi-disciplinary designer and content creator. I combine sleek, modern web development with bold, artistic graphic design to build memorable digital products. Across my YouTube channels, I share design tutorials, code-alongs, and creative videos.",
    skills: ["Webflow & Framer", "Brand Identity", "Figma"],
    avatarUrl: toyYtImg,
    heroBackgroundUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&h=600&q=80",
    backgroundVideoUrl: "/assets/background.mp4",
    backgroundVideoOpacity: 30
  },
  youtubeChannels: [
    {
      id: "yt-1",
      name: "Toeeifr",
      handle: "@toeeimc",
      subscribers: "1.48K",
      videosCount: "0",
      channelLink: "https://www.youtube.com/@Toeeimc",
      imageUrl: toyForImg,
      description: "Official Minecraft and Gaming channel. Creative video production and gameplay showcases.",
      accentColor: "#ef4444", // Red
      tags: ["Minecraft", "Gaming"]
    },
    {
      id: "yt-2",
      name: "Toeei",
      handle: "@ToeeiYT",
      subscribers: "110",
      videosCount: "17",
      channelLink: "https://www.youtube.com/@ToeeiYT",
      imageUrl: toyYtImg,
      description: "Roblox",
      accentColor: "#ec4899", // Pink
      tags: ["Roblox", "Gaming"]
    },
    {
      id: "yt-3",
      name: "LeekLarp",
      handle: "@leeklarpmc",
      subscribers: "4",
      videosCount: "0",
      channelLink: "https://www.youtube.com/@leeklarpmc",
      imageUrl: lelarImg,
      description: "Larping",
      accentColor: "#f59e0b", // Amber
      tags: ["Larp"]
    }
  ],
  works: [
    {
      id: "w-1",
      title: "Apex Streetwear E-Commerce",
      category: "Web Design",
      description: "A dark-mode, neo-brutalist shopping experience featuring fluid micro-interactions and horizontal sliding catalogs.",
      link: "https://github.com",
      imageUrl: "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&w=600&h=450&q=80",
      tags: ["E-Commerce", "Next.js", "Framer Motion"],
      featured: true
    },
    {
      id: "w-2",
      title: "Komorebi Ceremonial Matcha",
      category: "Graphic Design",
      description: "A complete brand strategy, typographic identity system, and eco-friendly tin packaging design for a premium matcha company.",
      link: "https://dribbble.com",
      imageUrl: "https://images.unsplash.com/photo-1536256263959-770b48d82b0a?auto=format&fit=crop&w=600&h=450&q=80",
      tags: ["Branding", "Packaging", "Art Direction"],
      featured: true
    },
    {
      id: "w-3",
      title: "Stark Finance Dashboard UI",
      category: "Web Design",
      description: "High-density data visualization system designed with focus on clarity, modular widgets, and micro-animations.",
      link: "https://figma.com",
      imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=600&h=450&q=80",
      tags: ["SaaS", "Dashboard", "Figma"],
      featured: true
    },
    {
      id: "w-4",
      title: "Synthetix Poster Series",
      category: "Graphic Design",
      description: "A visual exploration of Swiss typographic layouts fused with heavy acid-graphics textures and cybernetic themes.",
      link: "https://behance.net",
      imageUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&h=450&q=80",
      tags: ["Typography", "Poster Design", "Print"],
      featured: false
    },
    {
      id: "w-5",
      title: "Vanguard Record Co. Album Cover",
      category: "Graphic Design",
      description: "Retro-futuristic vinyl sleeve art and digital release packaging for an independent electronic synthwave duo.",
      link: "https://behance.net",
      imageUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=600&h=450&q=80",
      tags: ["Album Art", "Illustration", "Creative"],
      featured: false
    },
    {
      id: "w-6",
      title: "Zenith Architecture Landing Page",
      category: "Web Design",
      description: "Clean, geometric, image-forward web interface designed to showcase luxury minimalist residential projects.",
      link: "https://framer.com",
      imageUrl: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=600&h=450&q=80",
      tags: ["Web Design", "Minimalist", "Framer"],
      featured: false
    }
  ],
  contact: {
    discord: "toeeifr",
    gmail: "thatguyreaction@gmail.com",
    twitter: "sterling_design",
    github: "alexsterling"
  }
};

const STORAGE_KEY = 'creator_designer_portfolio_data_v3';

export function getPortfolioData(): PortfolioData {
  // Always return the standard database/hardcoded source of truth directly,
  // preventing stale customizer settings in localStorage from overriding user's requested channels
  return INITIAL_PORTFOLIO_DATA;
}

export function savePortfolioData(data: PortfolioData): void {
  // No-op to disable customizer saving
}

export function resetPortfolioData(): PortfolioData {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (e) {
    console.error('Failed to reset portfolio data', e);
  }
  return INITIAL_PORTFOLIO_DATA;
}
