import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Ensure data folder exists
  const DATA_DIR = path.join(process.cwd(), "data");
  const MESSAGES_FILE = path.join(DATA_DIR, "messages.json");
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(MESSAGES_FILE)) {
    fs.writeFileSync(MESSAGES_FILE, JSON.stringify([], null, 2));
  }

  // API Route: Submit message (Public route - no admin authorization required)
  app.post("/api/messages", (req, res) => {
    try {
      const { name, email, subject, message } = req.body;
      if (!name || !email || !message) {
        return res.status(400).json({ error: "Name, email, and message are required." });
      }

      const messages = JSON.parse(fs.readFileSync(MESSAGES_FILE, "utf-8"));
      const newMessage = {
        id: String(Date.now() + Math.random().toString(36).substring(2, 6)),
        name,
        email,
        subject: subject || "No Subject",
        message,
        timestamp: new Date().toISOString(),
        status: "unread",
      };

      messages.push(newMessage);
      fs.writeFileSync(MESSAGES_FILE, JSON.stringify(messages, null, 2));

      res.status(201).json({ success: true, data: newMessage });
    } catch (error) {
      console.error("Error saving message:", error);
      res.status(500).json({ error: "Failed to save message." });
    }
  });

  // Authorization middleware for admin operations
  const checkAdminAuth = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const passcode = req.headers["x-admin-passcode"];
    if (passcode !== "admin123") {
      return res.status(401).json({ error: "Unauthorized access to admin API." });
    }
    next();
  };

  // API Route: Get all messages (Protected)
  app.get("/api/messages", checkAdminAuth, (req, res) => {
    try {
      const messages = JSON.parse(fs.readFileSync(MESSAGES_FILE, "utf-8"));
      res.json({ success: true, data: messages });
    } catch (error) {
      console.error("Error reading messages:", error);
      res.status(500).json({ error: "Failed to load messages." });
    }
  });

  // API Route: Mark message status (Protected)
  app.patch("/api/messages/:id", checkAdminAuth, (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body; // 'read' or 'unread'
      if (!status) {
        return res.status(400).json({ error: "Status is required." });
      }

      let messages = JSON.parse(fs.readFileSync(MESSAGES_FILE, "utf-8"));
      let updated = false;

      messages = messages.map((m: any) => {
        if (m.id === id) {
          updated = true;
          return { ...m, status };
        }
        return m;
      });

      if (!updated) {
        return res.status(404).json({ error: "Message not found." });
      }

      fs.writeFileSync(MESSAGES_FILE, JSON.stringify(messages, null, 2));
      res.json({ success: true, message: `Message marked as ${status}.` });
    } catch (error) {
      console.error("Error updating message:", error);
      res.status(500).json({ error: "Failed to update message." });
    }
  });

  // API Route: Delete message (Protected)
  app.delete("/api/messages/:id", checkAdminAuth, (req, res) => {
    try {
      const { id } = req.params;
      let messages = JSON.parse(fs.readFileSync(MESSAGES_FILE, "utf-8"));
      const initialLength = messages.length;

      messages = messages.filter((m: any) => m.id !== id);

      if (messages.length === initialLength) {
        return res.status(404).json({ error: "Message not found." });
      }

      fs.writeFileSync(MESSAGES_FILE, JSON.stringify(messages, null, 2));
      res.json({ success: true, message: "Message deleted successfully." });
    } catch (error) {
      console.error("Error deleting message:", error);
      res.status(500).json({ error: "Failed to delete message." });
    }
  });

  // Vite integration
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
