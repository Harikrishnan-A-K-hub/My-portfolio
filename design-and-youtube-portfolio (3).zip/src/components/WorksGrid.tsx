import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Palette, ArrowRight, ArrowLeft, ExternalLink, Copy, Check } from 'lucide-react';
import { DesignWork } from '../types';

interface WorksGridProps {
  works: DesignWork[];
}

export default function WorksGrid({ works }: WorksGridProps) {
  const [showLinkPage, setShowLinkPage] = useState(false);
  const [copied, setCopied] = useState(false);

  const projectUrl = "https://portfolios-works.vercel.app/";

  const handleCopyLink = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    navigator.clipboard.writeText(projectUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section id="works-section" className="py-24 px-4 bg-transparent relative overflow-hidden border-t border-neutral-900">
      {/* Background ambient light */}
      <div className="absolute top-1/4 right-1/4 w-80 h-80 bg-red-600/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-rose-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-6xl mx-auto relative z-10">
        
        <AnimatePresence mode="wait">
          {!showLinkPage ? (
            <motion.div
              key="main-portfolio"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.4 }}
              className="space-y-16"
            >
              {/* Section Header */}
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2 text-red-500 font-semibold text-sm uppercase tracking-widest">
                      <Palette className="w-4 h-4" />
                      <span>02 / Creative Portfolio</span>
                    </div>
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wider bg-red-500/10 border border-red-500/20 text-red-400 animate-pulse">
                      ● Looking for Work
                    </span>
                  </div>
                  <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-display">
                    Creative Designs & Layouts
                  </h2>
                  <p className="max-w-xl text-neutral-400 text-sm sm:text-base leading-relaxed">
                    Currently focusing on bespoke visual communication, layout development, and branding identities.
                  </p>
                </div>
              </div>

              {/* Elegant Centered Clickable Box */}
              <div className="flex justify-center items-center">
                <button 
                  onClick={() => setShowLinkPage(true)}
                  className="relative w-full max-w-2xl rounded-3xl border border-dashed border-neutral-800/80 bg-neutral-950/40 hover:border-red-500/30 hover:bg-neutral-950/60 hover:shadow-[0_0_30px_rgba(239,68,68,0.05)] transition-all duration-500 flex flex-col justify-center items-center p-8 sm:p-12 text-center group overflow-hidden cursor-pointer text-left"
                >
                  {/* Grid background decorative layout inside the blank box */}
                  <div className="absolute inset-0 bg-[linear-gradient(to_right,#141414_1px,transparent_1px),linear-gradient(to_bottom,#141414_1px,transparent_1px)] bg-[size:1.5rem_1.5rem] opacity-30 pointer-events-none" />
                  
                  <div className="relative z-10 space-y-4">
                    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider bg-red-500/10 border border-red-500/20 text-red-400">
                      ● Available Now
                    </div>
                    
                    <h3 className="text-xl sm:text-3xl font-extrabold text-white tracking-tight font-display group-hover:text-red-400 transition-colors text-center w-full">
                      Looking for clients to work.
                    </h3>
                    
                    <p className="max-w-md mx-auto text-neutral-400 text-xs sm:text-sm leading-relaxed text-center">
                      Interested in high-quality web visual direction, branding identity projects, or layout consulting? Click to view my full project portfolio.
                    </p>

                    <div className="pt-2 flex flex-wrap justify-center items-center gap-4 sm:gap-6 w-full">
                      <span className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-xs font-bold uppercase tracking-widest text-white bg-red-500/20 border border-red-500/40 group-hover:bg-red-500/30 group-hover:border-red-500/60 shadow-[0_0_15px_rgba(239,68,68,0.1)] transition-all duration-300">
                        <span>View Project Portfolio</span>
                        <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" />
                      </span>
                      
                      <span 
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          const element = document.getElementById("contact-section");
                          if (element) {
                            element.scrollIntoView({ behavior: 'smooth' });
                          }
                        }}
                        className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-neutral-400 hover:text-white transition-colors"
                      >
                        <span>Get In Touch</span>
                      </span>
                    </div>
                  </div>
                </button>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="project-link-page"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.4 }}
              className="space-y-12"
            >
              {/* Navigation Back Button */}
              <div>
                <button
                  onClick={() => setShowLinkPage(false)}
                  className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-neutral-400 hover:text-white transition-colors cursor-pointer group"
                >
                  <ArrowLeft className="w-4 h-4 transform group-hover:-translate-x-1 transition-transform" />
                  <span>Back to Portfolio Overview</span>
                </button>
              </div>

              {/* Title & Info for Redirect Page */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-red-500 font-semibold text-sm uppercase tracking-widest">
                  <Palette className="w-4 h-4" />
                  <span>External Project Reference</span>
                </div>
                <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-display">
                  Project Hub & Showcase Link
                </h2>
                <p className="max-w-xl text-neutral-400 text-sm leading-relaxed">
                  You are being directed to the live creative workspace. Click the official link box below to open the external showcase website.
                </p>
              </div>

              {/* Interactive Small Link Box Container */}
              <div className="flex justify-center items-center py-6">
                <div className="w-full max-w-xl bg-neutral-950/80 border border-neutral-800/80 p-6 sm:p-8 rounded-2xl shadow-xl flex flex-col items-center justify-center space-y-6 relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-red-500/5 via-transparent to-transparent opacity-50" />
                  
                  {/* Subtle Indicator */}
                  <span className="relative z-10 text-[10px] uppercase font-mono tracking-widest text-neutral-500">
                    Official Portfolio Link
                  </span>

                  {/* The small box with the link inside */}
                  <a
                    href={projectUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="relative z-10 w-full bg-neutral-900 hover:bg-neutral-900/80 border border-neutral-800 hover:border-red-500/30 px-5 py-4 rounded-xl flex items-center justify-between gap-4 transition-all duration-300 group cursor-pointer text-left"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="p-2 rounded-lg bg-red-500/10 text-red-400 group-hover:scale-105 transition-transform duration-300">
                        <ExternalLink className="w-4 h-4" />
                      </div>
                      <span className="text-sm sm:text-base font-semibold text-neutral-200 group-hover:text-white transition-colors truncate">
                        {projectUrl}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={handleCopyLink}
                        title="Copy Link"
                        className="p-2 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-400 hover:text-white transition-colors"
                      >
                        {copied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                      <span className="hidden sm:inline-block text-[11px] font-bold uppercase tracking-widest text-red-400 group-hover:text-red-300 transition-colors">
                        Visit Site
                      </span>
                    </div>
                  </a>

                  <p className="relative z-10 text-xs text-neutral-400 text-center leading-relaxed">
                    Click anywhere inside the box above or use the buttons to navigate directly to the verified external showcase website.
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}

